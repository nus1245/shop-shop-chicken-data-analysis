# 치킨집 초벌 닭 산정

경험 기반 의사결정을 데이터로 전환하는 수요 예측 프로젝트

> "오늘 몇 (kg) 초벌해야 하는가"를 데이터로 예측할 수 있는가?

---

## 개요

닭강정 배달·포장 매장(shop&shop)에서, 치킨 사업 경험이 없는 사장님이 감각으로 결정해온
**초벌 닭 준비량**을 데이터 기반으로 예측하는 프로젝트입니다. 배달 플랫폼 주문 영수증을
OCR로 자동 파싱해 MySQL에 적재하고, 통계적 가설검증과 회귀분석 및 Tableau
대시보드로 전달하는 전체 파이프라인(AtoZ)활동을 혼자 설계·구현했습니다.

| 항목 | 내용 |
|---|---|
| 기간 | 2026.05 ~ 2026.08.21 |
| 데이터 | 배달 플랫폼 주문 영수증 (분석 기준 45일·1,043건, 일평균 약 23건 · 목요일 대타 1일 제외) |
| 기술 스택 | Python · MySQL · Tableau · Claude Agent(OCR) · Google Drive |

## 파이프라인

```
영수증 촬영 → Google Drive → Claude Agent OCR → MySQL 적재 → Python 분석 → Tableau 전달
수기 (외부)데이터 → Python(coldab) 데이터 변환 스크립트 → Google Drive 보관  → MySQL 적재 → Python 분석 → Tableau 전달 
```

- **수집**: 배달 영수증을 촬영해 Google Drive에 업로드하면 OCR로 메뉴·수량·시간을 자동 파싱
- **적재**: `daily_chicken_log`(1일 1행, 운영 로그) : `order_detail_log`(1일 N행, 상세 주문) = 1:N 구조
- **분석**: 가설검증 → 요일별 모델링 시도 → 소표본 과적합 확인 → 통합 데이터 재설계 → 사후 검증
- **전달**: Tableau 대시보드 (월-주간 리포트 + 일별 상세 로그)

## 핵심 발견
- **H1 기각**: 요일별(월화금) 소비량 차이가 유의하지 않다.(F=2.585, p=0.087 ANOVA)
- **H2 채택**: 특수일(공휴일 및 휴일전) 소비가 평일 소비보다 유의하게 많음 (t=-2.108, p=0.0409, Hedges' g=0.63 T-TEST)
- **H3 채택**: 오후(16-19시) 소비가 저녁(20-22시)보다 유의하게 많음 (t=3.605, p=0.0008, Cohen's d=0.54 PAIRED T-TEST)
- **요일별 분리 모델의 함정**: 화요일 단독 스텝와이즈 OLS는 Adj R²=0.942로 매우 높게 나왔지만,
  관측치 5개·잔차 자유도 2에 불과해 통계적으로 신뢰 불가능함을 직접 실증. 인접 시간대(T2)에
  같은 방법론을 적용하자 F검정이 기각 실패(p=0.171)로 정반대 결과가 나와, 소표본 분리의
  위험성을 재확인함
- **통합 모델 채택**:
-  **T1 모델 (1차 피크, 16-19시)**: baseline(단순 평균) 대비, 3일 평균 저녁 소비량·격주 전 같은요일
오후 소비량·특수일(연휴전날) 여부·3일 평균 오후 소비량을 피처로 한 회귀모델 구축
(R²=0.398, Adj R²=0.301, F=4.13, p=0.011). 8월 홀드아웃(n=9) 검증 결과 baseline 대비
RMSE 16.6% 개선
  - 3일 평균 저녁 소비량 1kg↑ → 오후 +746g (p=0.016)
  - 격주 전 같은요일 오후 소비량 1kg↑ → 오후 +364g (p=0.037)
  - 특수일(연휴전날) 여부 → 오후 +1,741g (p=0.087, 경계선)
  - 3일 평균 오후 소비량 1kg↑ → 오후 −541g (p=0.072, 평균회귀 경향)
- **T2 모델 (2차 피크, 20-22:45)**: 5-8월 전체(n=39) 사용, 홀드아웃 없는 탐색적 결과.
`rain_status` 단일 피처로 R²=0.140, p=0.019 — 우천 시(0→1) 저녁 소비 평균 −2,939g 감소.
설명력 14%에 그쳐 저녁 수요의 86%는 현재 변수로 설명되지 않음
- **이상치의 잔차→레버리지 전이**: 특정 이상치가 발생 시점에는 잔차(Y) 문제로, lag 피처
  구조상 정확히 7일 뒤에는 레버리지(X) 문제로 형태를 바꿔 전이됨을 Cook's D로 확인
  (0.133→0.391, 임계값 0.2→0.167 초과)
- **사후 시뮬레이션**: 학습에 쓰지 않은 신규 데이터(n=9 )에 모델을 적용해 사장님의 감각(A),
  모델 예측(B), 단순 일평균(C)을 비교. 

## 폴더 구조

```
python_code/
├── 01_eda_hypothesis_test.ipynb        # EDA + H1~H3 가설검증
├── 02_feature_correlation_dilution.ipynb  # 상관계수 희석 진단
├── 03_tuesday_solo_model.ipynb          # 화요일 단독 스텝와이즈 OLS (과적합 실증)
├── 04_integrated_model_loocv.ipynb      # 통합 데이터 baseline + LOOCV 모델
├── 05_posthoc_simulation.ipynb          # 사후 검증 시뮬레이션
├── 06_outlier_leverage_analysis.ipynb   # 이상치 잔차→레버리지 전이 검증
└── 07_integerated_model.ipynb           # 최종 모델 


SQL_query/
├── 01_schema_and_import.sql             # 테이블 스키마 + CSV 적재
├── 02_base_table_preprocessing.sql      # 베이스 테이블 전처리
├── 03_feature_engineering.sql           # lag·rolling 피처 뷰
├── 04_hypothesis_test_prep.sql          # 가설검증용 전처리
├── 05_dashboard_peak_time.sql           # 피크타임 대시보드 쿼리
├── 06_dashboard_kpi_using_rate.sql       # 소진율(U-rate) 대시보드 쿼리
└── 99_archive_feature_query_draft.sql   # 초기 draft (아카이브)
```

## 개발 방식 (Methodology Note)

가설·분석 방향(어떤 통계 기법을 쓸지, 결과를 어떻게 해석 방법론)은 직접 설계했으며, 통계 기법의
python 코드 구현은 AI 코드 어시스턴트(Claude)와 논의하며 기초 골격을 빠르게 잡은 뒤, 프로젝트
데이터의 소표본·요일별 구조에 맞게 직접 발전시켰습니다. 이후 코드 리펙토링 작업을 AI 코드 어시스턴트를 활용하여 가독성을 증진했습니다.
## 작성자

조승훈 — 데이터 분석가(주니어) 지망 ·
E-MAIL : nextbus1245@gmail.com 

해당 프로젝트 노션 기록 : https://app.notion.com/p/36522de4a40981c1b1a0c2e6177e8c9a?source=copy_link

Tableau 월간 dash_board : [https://public.tableau.com/views/Monthly-WeeklyReport/___3?:language=ko-KR&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link](https://public.tableau.com/views/_17885736711600/___3?:language=ko-KR&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link)


Tableau 일별 상세 dash_board : [https://public.tableau.com/views/Daily-Log/___4?:language=ko-KR&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link
](https://public.tableau.com/views/_17885736348380/___4?:language=ko-KR&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link)
